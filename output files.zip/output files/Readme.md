# Missionaries and Cannibals — Uninformed Search

**AI Programming Assignment 3**

---

## Problem Statement

Three missionaries and three cannibals need to cross a river using a boat that carries at most 2 people.
At no point can cannibals outnumber missionaries on either bank, or the missionaries will be eaten.

**Goal:** Move everyone from the left bank to the right bank.

---

## State Representation

Each state is a tuple: `(missionaries_left, cannibals_left, boat_side)`

| Field | Description |
|---|---|
| `missionaries_left` | Number of missionaries on the left bank (0–3) |
| `cannibals_left` | Number of cannibals on the left bank (0–3) |
| `boat_side` | `0` = boat on left bank, `1` = boat on right bank |

- **Start State:** `(3, 3, 0)` — everyone on the left
- **Goal State:** `(0, 0, 1)` — everyone on the right

---

## Algorithms Implemented

### 1. BFS — Breadth-First Search
Explores all states level by level using a **FIFO queue**.
Guarantees the shortest (optimal) solution.

### 2. DFS — Depth-First Search
Explores as deep as possible before backtracking using a **LIFO stack**.
Memory efficient but does not guarantee the shortest path.

### 3. IDDFS — Iterative Deepening DFS
Runs depth-limited DFS repeatedly with increasing depth limits (0, 1, 2, ...).
Combines BFS optimality with DFS memory efficiency.

---

## How to Run

```bash
python missionaries_cannibals.py
```

No external libraries required — uses only Python's built-in `collections` and `time`.

---

## Output

### BFS
![BFS Output](output_bfs.png)

### DFS
![DFS Output](output_dfs.png)

### IDDFS
![IDDFS Output](output_iddfs.png)

### Performance Comparison
![Comparison](output_comparison.png)

---

## Performance Summary

| Algorithm | Steps | Nodes Explored | Optimal? | Memory |
|---|---|---|---|---|
| BFS | 11 | 15 | ✅ Yes | Higher |
| DFS | 11 | 12 | ❌ Not guaranteed | Lower |
| IDDFS | 11 | 66 | ✅ Yes | Lower |

---

## Files

| File | Description |
|---|---|
| `missionaries_cannibals.py` | Main implementation (BFS, DFS, IDDFS) |
| `output_bfs.png` | BFS execution screenshot |
| `output_dfs.png` | DFS execution screenshot |
| `output_iddfs.png` | IDDFS execution screenshot |
| `output_comparison.png` | Performance comparison screenshot |
| `README.md` | This file |
